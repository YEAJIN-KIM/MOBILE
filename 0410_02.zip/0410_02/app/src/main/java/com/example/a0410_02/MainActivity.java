package com.example.a0410_02;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    RadioButton rb1,rb2,rb3;
    int pressed =0;
    View dialogView;
    String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg =(RadioGroup)findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i== R.id.radioButton)
                pressed = 0;
                else if (i== R.id.radioButton2)
                    pressed = 1;
                else
                    pressed = 2;
            }
        });
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogView = (View)View.inflate(MainActivity.this,R.layout.dialog,null);
                ImageView iv =(ImageView)dialogView.findViewById(R.id.imageView);
                switch (pressed) {
                    case 0:
                    iv.setImageResource(R.drawable.dog);
                    title ="강아지";
                    break;
                    case 1:
                        iv.setImageResource(R.drawable.cat);
                        title ="고양이";
                        break;
                    case 2:
                        iv.setImageResource(R.drawable.rabbit);
                        title ="토끼";
                        break;
                }
                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle(title)
                        .setView(dialogView)
                        .setNeutralButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                try {
                                    this.finalize();
                                } catch (Throwable throwable) {
                                    throwable.printStackTrace();
                                }
                            }
                        })
                        .show();

            }
        });
    }
}
